USE ap;

INSERT INTO invoices VALUES
(115, 97, '456789', '2014-08-01', 8344.50, 0, 0, 1, '2014-08-31', NULL);

-- clean up
-- DELETE FROM invoices WHERE invoice_id >= 115;

