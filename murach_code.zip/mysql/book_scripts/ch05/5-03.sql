USE ex;

INSERT INTO color_sample (color_number)
VALUES (606);

INSERT INTO color_sample (color_name)
VALUES ('Yellow');

INSERT INTO color_sample
VALUES (DEFAULT, DEFAULT, 'Orange');

INSERT INTO color_sample
VALUES (DEFAULT, 808, NULL);

INSERT INTO color_sample
VALUES (DEFAULT, DEFAULT, NULL);