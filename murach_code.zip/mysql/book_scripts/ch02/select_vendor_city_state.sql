SELECT vendor_name, vendor_city, vendor_state
FROM vendors
ORDER BY vendor_name;