USE ap;

REPAIR TABLE vendors;

REPAIR TABLE vendors, invoices QUICK;