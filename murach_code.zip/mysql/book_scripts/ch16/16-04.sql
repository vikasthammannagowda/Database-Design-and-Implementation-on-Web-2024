SHOW TRIGGERS;

SHOW TRIGGERS IN ex;

SHOW TRIGGERS IN ap LIKE 'ven%';

DROP TRIGGER vendors_before_update;

DROP TRIGGER IF EXISTS vendors_before_update;