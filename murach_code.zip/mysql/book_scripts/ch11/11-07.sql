RENAME TABLE vendors TO vendor;

TRUNCATE TABLE vendor;

DROP TABLE vendor;

DROP TABLE ex.vendor;

DROP TABLE vendors;