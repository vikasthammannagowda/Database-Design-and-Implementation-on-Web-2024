Each figure that contains one or more SQL statements has a corresponding file. 
For example, figure 3-2 has a corresponding file named 3-02.sql. Within these files
each SQL statement ends with a semicolon.

If you're using MySQL Workbench, you can open a .sql file. Then, you can use these 
skills to execute the statements in the file:

* To execute a single statement, move the cursor into the statement and press Ctrl+Enter.
* To execute the entire script, press Ctrl+Shift+Enter.